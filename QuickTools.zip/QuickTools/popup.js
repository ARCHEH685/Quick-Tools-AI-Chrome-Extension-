// Basic safety filter
const bannedWords = [
  "sex","sexy","nsfw","nude","naked","kill","murder",
  "racist","hate","slur","fuck","shit","bitch",
  "drug","drugs","weapon","gun","knife"
];

function isBlocked(text) {
  const lower = text.toLowerCase();
  for (const bad of bannedWords) {
    if (lower.includes(bad)) return true;
  }
  return false;
}

// Tab switching
document.querySelectorAll(".tab").forEach(tab => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
    document.querySelectorAll(".section").forEach(s => s.classList.remove("active"));

    tab.classList.add("active");
    const target = tab.getAttribute("data-target");
    document.getElementById(target).classList.add("active");
  });
});

// Core syllables (ASCII only)
const s1 = ["Ka","Xe","Lo","Va","Re","Zi","Astra","Neo","Cy","Quo","Ly","Or","Vira","Zan"];
const s2 = ["ron","tek","lith","vex","drax","nox","lume","vion","ther","rax","mir","dell","vyr","kesh"];
const s3 = ["os","ium","ex","ar","on","is","en","or","yx","ul","eth","an"];

function generateCore() {
  return (
    s1[Math.floor(Math.random() * s1.length)] +
    s2[Math.floor(Math.random() * s2.length)] +
    s3[Math.floor(Math.random() * s3.length)]
  );
}

// NAMES
document.getElementById("name-generate").addEventListener("click", () => {
  const input = document.getElementById("name-input").value.trim();
  const result = document.getElementById("name-result");

  if (!input) {
    result.textContent = "Type something first!";
    return;
  }

  if (isBlocked(input)) {
    result.textContent = "I could not do that.";
    return;
  }

  const vibe = input.toLowerCase();
  let output;

  if (vibe.includes("full")) {
    output = generateCore() + " " + generateCore();
  } else if (vibe.includes("fantasy")) {
    output = generateCore() + " of " + generateCore();
  } else if (vibe.includes("sci") || vibe.includes("space")) {
    output = generateCore() + "-" + generateCore();
  } else {
    output = generateCore();
  }

  result.textContent = output;
});

// USERNAMES
document.getElementById("user-generate").addEventListener("click", () => {
  const input = document.getElementById("user-input").value.trim();
  const result = document.getElementById("user-result");

  if (!input) {
    result.textContent = "Type something first!";
    return;
  }

  if (isBlocked(input)) {
    result.textContent = "I could not do that.";
    return;
  }

  const base = generateCore().toLowerCase();
  const num = Math.floor(Math.random() * 9999);
  const clean = base.replace(/[^a-z0-9]/gi, "");

  const vibe = input.toLowerCase();
  let username;

  if (vibe.includes("gaming")) {
    username = clean + num;
  } else if (vibe.includes("clean")) {
    username = clean;
  } else if (vibe.includes("aesthetic")) {
    username = clean + "_ai";
  } else if (vibe.includes("edgy")) {
    username = "x" + clean + "x";
  } else {
    username = clean + "_" + num;
  }

  result.textContent = username;
});

// PASSWORDS
document.getElementById("pass-generate").addEventListener("click", () => {
  const length = parseInt(document.getElementById("pass-length").value, 10);
  const result = document.getElementById("pass-result");

  const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*_-+=?";
  let password = "";

  for (let i = 0; i < length; i++) {
    password += chars[Math.floor(Math.random() * chars.length)];
  }

  result.textContent = password;
});

// PLANETS
document.getElementById("planet-generate").addEventListener("click", () => {
  const input = document.getElementById("planet-input").value.trim();
  const result = document.getElementById("planet-result");

  if (isBlocked(input)) {
    result.textContent = "I could not do that.";
    return;
  }

  const core = generateCore();
  const suffixes = [" Prime", " IX", " Station", " Colony", " Sector", " Haven", " Outpost"];
  const suffix = suffixes[Math.floor(Math.random() * suffixes.length)];

  result.textContent = core + suffix;
});

// CHARACTERS
document.getElementById("char-generate").addEventListener("click", () => {
  const input = document.getElementById("char-input").value.trim();
  const result = document.getElementById("char-result");

  if (isBlocked(input)) {
    result.textContent = "I could not do that.";
    return;
  }

  const roles = ["Explorer", "Pilot", "Inventor", "Guardian", "Scout", "Wanderer", "Strategist"];
  const role = roles[Math.floor(Math.random() * roles.length)];

  result.textContent = generateCore() + " the " + role;
});

// COLORS
document.getElementById("color-generate").addEventListener("click", () => {
  const result = document.getElementById("color-result");

  function randHex() {
    const hex = Math.floor(Math.random() * 16777215).toString(16);
    return "#" + hex.padStart(6, "0");
  }

  const c1 = randHex();
  const c2 = randHex();
  const c3 = randHex();

  result.textContent = c1 + "  |  " + c2 + "  |  " + c3;
});

// IDEAS
document.getElementById("idea-generate").addEventListener("click", () => {
  const result = document.getElementById("idea-result");

  const ideas = [
    "A futuristic tool concept",
    "A new sci-fi character",
    "A unique world idea",
    "A cool username theme",
    "A creative project starter",
    "A mysterious artifact concept",
    "A new planet civilization idea"
  ];

  result.textContent = ideas[Math.floor(Math.random() * ideas.length)];
});

// CHAT (simulated offline)
const chatBox = document.getElementById("chat-box");
const chatInput = document.getElementById("chat-input");
const chatSend = document.getElementById("chat-send");

function addChatMessage(text, from) {
  const div = document.createElement("div");
  div.className = "chat-message " + (from === "user" ? "chat-user" : "chat-bot");
  div.textContent = (from === "user" ? "You: " : "Bot: ") + text;
  chatBox.appendChild(div);
  chatBox.scrollTop = chatBox.scrollHeight;
}

chatSend.addEventListener("click", () => {
  const text = chatInput.value.trim();
  if (!text) return;

  if (isBlocked(text)) {
    addChatMessage("I could not respond to that.", "bot");
    chatInput.value = "";
    return;
  }

  addChatMessage(text, "user");
  chatInput.value = "";

  // Simple simulated response
  const replies = [
    "That sounds interesting.",
    "Nice idea. You could build on that.",
    "I like that direction.",
    "You are thinking creatively.",
    "That could become a cool project."
  ];
  const reply = replies[Math.floor(Math.random() * replies.length)];
  setTimeout(() => {
    addChatMessage(reply, "bot");
  }, 500);
});

// IMAGES (simulated offline)
document.getElementById("img-generate").addEventListener("click", () => {
  const input = document.getElementById("img-input").value.trim();
  const result = document.getElementById("img-result");

  if (!input) {
    result.textContent = "Type a prompt first!";
    return;
  }

  if (isBlocked(input)) {
    result.textContent = "I could not do that.";
    return;
  }

  // Simulated "AI-style" description
  result.textContent =
    "High-detail scene based on: \"" +
    input +
    "\" (this is a simulated description, not a real image).";
});